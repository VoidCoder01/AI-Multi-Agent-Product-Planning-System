# AI Multi-Agent Product Planning System

Multi-agent orchestration (BMAD-style): a user provides a product idea, the system asks clarifying questions, then **collaborating agents** produce structured artifacts — **project brief**, **PRD**, **epics**, **user stories**, **tasks**, and **subtasks**.

**Stack:** Python 3.11+, **FastAPI**, **OpenRouter** (Claude / any model), **LangGraph** (graph workflow), **React (Vite)** UI.

> **Phase 2 upgraded** — RAG foundation, document upload, vector retrieval + reranking, caching layer, SSE streaming, evaluation system, and structured observability are all live.

---

## System Architecture (Post-Upgrade)

```text
                    ┌─────────────────────────────────────┐
                    │   Master Orchestrator (LangGraph)   │
                    └──────────────┬──────────────────────┘
                                   │
     ┌─────────────────────────────┼─────────────────────────────┐
     ▼                             ▼                             ▼
 Clarification               Requirement                    PM Agent
 Agent (questions)           Agent (brief + RAG)           (PRD + RAG)
     │                             │                             │
     └─────────────────────────────┼─────────────────────────────┘
                                   ▼
                            Architect Agent
                          (technical design)
                                   ▼
                             Scrum Agent
                       (epics + user stories)
                                   ▼
                            Task Agent
                        (tasks + subtasks)
                                   ▼
                  ┌────────────────────────────┐
                  │      Evaluation System     │
                  │  EvaluatorAgent scores     │
                  │  relevance + hallucination │
                  └────────────────────────────┘

────────────────── Supporting Infrastructure ────────────────────

  Document Upload → Chunker → HashEmbedding → Vector Index
                                   ↓
                     VectorRetriever (top-k cosine)
                                   ↓
                     CrossEncoderReranker (BM25 + TF-IDF)
                                   ↓
                       Context Injection into Agents

  CacheLayer (Redis / in-memory fallback)
  JSONL Audit Logger · MemoryStore (session persistence)
  SSE Streaming · Mermaid Workflow Diagram API
```

---

## Repository Layout

```text
.
├── README.md                 # you are here
├── ARCHITECTURE.md           # extended design decisions
├── agents/
│   ├── base.py               # shared OpenRouter client + retry
│   ├── clarification_agent.py
│   ├── requirement_agent.py  # RAG context_chunks injection ✅
│   ├── pm_agent.py           # RAG context_chunks injection ✅
│   ├── architect_agent.py
│   ├── scrum_agent.py
│   └── task_agent.py
├── backend/
│   ├── main.py               # /api/upload /api/questions /api/generate /api/generate/stream
│   ├── orchestrator.py       # run_workflow + retrieve_context (RAG)
│   ├── prompt_loader.py
│   ├── prompts/              # Markdown + YAML frontmatter prompts
│   ├── validate_output.py    # CLI: check duplicate IDs
│   └── tests/                # pytest suite (agents, RAG, graph, API, validation)
├── utils/
│   ├── chunking.py           # overlapping token-based chunker ✅
│   ├── embeddings.py         # deterministic HashEmbeddingModel ✅
│   ├── retriever.py          # cosine-similarity VectorRetriever ✅
│   ├── reranker.py           # CrossEncoderReranker (BM25-style) ✅
│   ├── cache.py              # Redis + in-memory fallback CacheLayer ✅
│   ├── evaluator.py          # EvaluatorAgent (relevance/hallucination) ✅
│   ├── agent_logger.py       # JSONL audit log per LLM call ✅
│   ├── memory_store.py       # file-backed session store
│   └── runtime_config.py     # 12-factor env config
├── orchestrator/graph.py     # LangGraph compiled graph
├── schemas/                  # PlanningState TypedDict + Pydantic models
├── docs/                     # generated artifacts
└── frontend/                 # React + Vite UI
```

---

## Agent Design

| Agent | Responsibility | RAG-aware | Output |
|-------|----------------|-----------|--------|
| **Clarification** | Scope, users, features, constraints | — | JSON array of questions |
| **Requirement** | Structured brief from Q&A | ✅ | JSON: name, problem, users, features |
| **PM** | Brief review + PRD | ✅ | JSON: overview, goals, personas, NFR, metrics |
| **Architect** | Technical architecture | — | JSON: services, stack, data flow, scale |
| **Scrum** | Agile backlog | — | JSON: epics → stories → AC |
| **Task** | Engineering tasks breakdown | — | JSON: tasks + subtasks |
| **Evaluator** | QA scoring post-generation | — | JSON: relevance/hallucination scores |

---

## Phase 1 — RAG Foundation

### 1. Document Upload (`POST /api/upload`)

Upload a **PDF or TXT** file to inject domain knowledge into the pipeline:

```bash
CONTENT=$(base64 -w 0 spec.pdf)
curl -s -X POST http://127.0.0.1:8000/api/upload \
  -H "Content-Type: application/json" \
  -d "{\"filename\":\"spec.pdf\",\"content_base64\":\"$CONTENT\",\"session_id\":null}"
# → { "session_id": "abc123", "document": { "chunk_count": 18, ... } }
```

The **frontend** shows an **"Attach PDF/TXT Context"** button beneath the product idea textarea. Uploaded files are displayed as chips. The returned `session_id` is automatically passed to `/api/generate` to activate RAG retrieval.

### 2. Chunking (`utils/chunking.py`)

Token-aware chunker with 100-token overlap. Each chunk:
```json
{ "chunk_id": "spec.pdf:1", "text": "...", "source": "spec.pdf" }
```

### 3. Embeddings (`utils/embeddings.py`)

`HashEmbeddingModel` — deterministic 256-dim embeddings. No external API, no GPU.

### 4. Retrieval + Reranking

- `VectorRetriever` — cosine similarity top-k selection.
- `CrossEncoderReranker` — BM25-style re-scoring for precision.

### 5. Context Injection into Agents

`RequirementAgent` and `PMAgent` inject retrieved chunks into their prompts:

```text
Retrieved context:
- [spec.pdf] The system must support 10K concurrent users with P95 < 200ms...
```

`Orchestrator.retrieve_context()` wires this via session state.

---

## Phase 2 — Production Features

### 6. Streaming (`POST /api/generate/stream`)

SSE endpoint emits stage-level progress:
```json
{"stage": "requirement", "status": "started", "message": "Structuring your vision…"}
{"stage": "complete",    "status": "done",    "result": { ... }}
```

### 7. Caching (`utils/cache.py`)

`CacheLayer` wraps Redis with an in-memory fallback:
- **Embedding cache** — SHA-256 keyed, 24 h TTL
- **LLM response cache** — exact prompt match, 1 h TTL

Set `REDIS_URL` in `.env` for Redis. Omit for single-process in-memory mode.

### 8. Evaluation System (`utils/evaluator.py`)

```python
from utils.evaluator import EvaluatorAgent
score = EvaluatorAgent().evaluate_output(query, generated_document)
# → { "relevance_score": 9, "hallucination_score": 1, "feedback": "Accurate and grounded." }
```

### 9. Logging & Observability (`utils/agent_logger.py`)

Every LLM call appends a JSONL line to `logs/agent_audit.jsonl`:
```json
{
  "ts": "2026-04-20T18:00:00Z",
  "agent": "PM_AGENT",
  "phase": "prd",
  "status": "ok",
  "duration_ms": 4820,
  "input_preview": "...",
  "output_preview": "..."
}
```

---

## Setup

### Backend

```bash
cd /path/to/AI-Multi-Agent-Product-Planning-System
pip install -r backend/requirements.txt
cp .env.example .env
# Required: OPENROUTER_API_KEY
# Optional: REDIS_URL, OPENROUTER_MODEL, LLM_MAX_RETRIES, TASK_AGENT_MAX_WORKERS
uvicorn backend.main:app --reload --host 127.0.0.1 --port 8000
```

### Frontend

```bash
cd frontend && npm install && npm run dev
# → http://127.0.0.1:8080
```

Production build (served by FastAPI at `/ui/`):
```bash
cd frontend && npm run build
# → http://127.0.0.1:8000/ui/
```

**Swagger:** http://127.0.0.1:8000/docs

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/questions` | Generate clarification questions |
| `POST` | `/api/generate` | Run full planning pipeline |
| `POST` | `/api/generate/stream` | SSE streaming pipeline |
| `POST` | `/api/upload` | Upload PDF/TXT for RAG context |
| `GET`  | `/api/sessions` | List saved sessions |
| `GET`  | `/api/sessions/{id}` | Load session artifacts |
| `GET`  | `/api/workflow/diagram` | Mermaid graph of pipeline |
| `GET`  | `/health` | API + API key status |

---

## Testing

```bash
pytest backend/tests/ -v
# test_rag.py · test_agents.py · test_graph.py · test_api.py · test_validation.py
```

---

## Final Architecture Flow

```text
User Input
   ↓
Document Upload → Chunking → Embedding → Vector DB (session memory)
   ↓
Query → VectorRetriever → CrossEncoderReranker
   ↓
Context Injection → RequirementAgent + PMAgent
   ↓
LangGraph Multi-Agent Pipeline
  Clarify → Brief → PM Review + PRD → Architect → Scrum → Task
   ↓
EvaluatorAgent + JSONL Logger + CacheLayer
   ↓
Final Output (JSON / Markdown export)
```

---

## AI Tooling Disclosure

| Tool | Purpose |
|------|---------|
| Cursor / Antigravity (agent mode) | Implementation, refactors, UI, test scaffolding |
| OpenRouter (Claude via OpenAI-compat SDK) | Runtime LLM for all planning agents |
| pytest + Vitest | Regression: prompt loading, RAG, API, frontend |

---

## Features Beyond Base Spec

- [x] **RAG pipeline** — upload → chunk → embed → retrieve → rerank → inject
- [x] **Evaluation system** — `EvaluatorAgent` (relevance + hallucination scoring)
- [x] **Caching layer** — Redis + in-memory fallback
- [x] **SSE streaming** — `/api/generate/stream`
- [x] **Architect Agent** — 6th bonus agent
- [x] **Cross-document validation** — consistency checks across all artifacts
- [x] **Review loops** — PM reviews brief; Scrum reviews PRD; Task validates feasibility
- [x] **Parallel task generation** — configurable `TASK_AGENT_MAX_WORKERS`
- [x] **Session memory** — full pipeline results per session
- [x] **Structured audit logging** — JSONL with duration, phase, truncated I/O
- [x] **Workflow visualization** — Mermaid diagram via `/api/workflow/diagram`
- [x] **Frontend file upload** — PDF/TXT attach button + chip list in UI

---

## License

MIT — see [LICENSE](LICENSE).
